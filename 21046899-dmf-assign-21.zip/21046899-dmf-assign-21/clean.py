# script filters to remove any dud records where there is no value for SiteID or there is a mismatch between SiteID and Location
import pandas as pd

address = "crop.csv"
bristolAirQuality = pd.read_csv(address)
baq = bristolAirQuality

monitoring_stataions = {
188: 'AURN Bristol Centre',
203: 'Brislington Depot',
206: 'Rupert Street',
209: 'IKEA M32',
213: 'Old Market',
215: 'Parson Street School',
228: 'Temple Meads Station',
270: 'Wells Road',
271: 'Trailer Portway P&R',
375: 'Newfoundland Road Police Station',
395: "Shiner's Garage",
452: 'AURN St Pauls',
447: 'Bath Road',
459: 'Cheltenham Road \ Station Road',
463: 'Fishponds Road',
481: 'CREATE Centre Roof',
500: 'Temple Way',
501: 'Colston Avenue'   
}



baq2 = baq.copy() # this returns a copy of a set of baq as baq2

for r, v in monitoring_stataions.items(): # this script loops through the monitoring station to replace 'SiteID' (where r and v is replace and value)
    baq2['SiteID'].replace(to_replace = r, value = v, inplace = True)

baq3 = baq.drop(baq[baq2['SiteID'] != baq2['Location']].index)

# dud entries
dud_entries = baq[(baq2['SiteID'] != baq2['Location'])]
dud_entries.index = dud_entries.index + 2

for line_number, mismatch_field in zip(dud_entries.index, dud_entries['SiteID']): # this loops through all the mismatches
    print(line_number, str(mismatch_field).rjust(10))
    
baq3.to_csv('clean.csv') # gets the clean csv as well as the mismatches '''

