# to scripts crops the file to remove every brisstolAirQuality records before 2010-01-01
import pandas as pd

airQuality = pd.read_csv('bristol-air-quality-data.csv', delimiter = ";")

airQuality['Date Time'] = pd.to_datetime(airQuality['Date Time'])

bristolAirQuality = airQuality[(airQuality['Date Time'] >= '2010-01-01 00:00:00')]

bristolAirQuality.to_csv("crop.csv")

print(bristolAirQuality)